package com.example.notifikasi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
